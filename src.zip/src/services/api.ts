const API_BASE_URL = 'http://localhost:5000/api';

// Helper function to get auth token
const getAuthToken = () => {
  return localStorage.getItem('token');
};

// Helper function to set auth token
const setAuthToken = (token: string) => {
  localStorage.setItem('token', token);
};

// Helper function to remove auth token
const removeAuthToken = () => {
  localStorage.removeItem('token');
};

// Helper function to make API requests
const apiRequest = async (endpoint: string, options: RequestInit = {}) => {
  const token = getAuthToken();
  
  const config: RequestInit = {
    headers: {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...options.headers,
    },
    ...options,
  };

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || 'API request failed');
    }

    return data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
};

// Auth API
export const authAPI = {
  register: async (name: string, email: string, password: string) => {
    return apiRequest('/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, password }),
    });
  },

  login: async (email: string, password: string) => {
    const data = await apiRequest('/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    
    if (data.token) {
      setAuthToken(data.token);
    }
    
    return data;
  },

  logout: () => {
    removeAuthToken();
  },

  getToken: () => getAuthToken(),
};

// User API
export const userAPI = {
  getProfile: async () => {
    return apiRequest('/profile');
  },

  updateProfile: async (profileData: any) => {
    return apiRequest('/profile', {
      method: 'PUT',
      body: JSON.stringify(profileData),
    });
  },

  getAllUsers: async () => {
    return apiRequest('/users');
  },
};

// Skills API
export const skillsAPI = {
  addSkill: async (skill: string, type: 'offered' | 'wanted') => {
    return apiRequest('/skills', {
      method: 'PUT',
      body: JSON.stringify({ skill, type, action: 'add' }),
    });
  },

  removeSkill: async (skill: string, type: 'offered' | 'wanted') => {
    return apiRequest('/skills', {
      method: 'PUT',
      body: JSON.stringify({ skill, type, action: 'remove' }),
    });
  },
};

// Swaps API
export const swapsAPI = {
  createSwap: async (toUserId: string, offeredSkill: string, wantedSkill: string, message?: string) => {
    return apiRequest('/swaps', {
      method: 'POST',
      body: JSON.stringify({ toUserId, offeredSkill, wantedSkill, message }),
    });
  },

  getSwaps: async () => {
    return apiRequest('/swaps');
  },

  updateSwapStatus: async (swapId: string, status: string, rating?: number) => {
    return apiRequest(`/swaps/${swapId}`, {
      method: 'PUT',
      body: JSON.stringify({ status, rating }),
    });
  },
};

// Admin API
export const adminAPI = {
  getStats: async () => {
    return apiRequest('/admin/stats');
  },
};

export default {
  auth: authAPI,
  user: userAPI,
  skills: skillsAPI,
  swaps: swapsAPI,
  admin: adminAPI,
}; 