import React, { useState, useEffect } from 'react';

interface PendingReview {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  skillName: string;
  description: string;
  submittedAt: string;
  status: 'pending' | 'approved' | 'rejected';
}

interface User {
  id: string;
  name: string;
  email: string;
  status: 'active' | 'suspended' | 'banned';
  lastActive: string;
  joinDate: string;
  totalSwaps: number;
  avgRating: number;
}

interface PlatformMetrics {
  totalUsers: number;
  activeSwaps: number;
  completedSwaps: number;
  avgRating: number;
  pendingReviews: number;
  suspendedUsers: number;
}

export const AdminSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'reviews' | 'users' | 'notifications'>('overview');
  const [showNotificationModal, setShowNotificationModal] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState('');
  const [pendingReviews, setPendingReviews] = useState<PendingReview[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [metrics, setMetrics] = useState<PlatformMetrics>({
    totalUsers: 1247,
    activeSwaps: 189,
    completedSwaps: 912,
    avgRating: 4.3,
    pendingReviews: 5,
    suspendedUsers: 3
  });

  // Mock data for pending reviews
  const mockPendingReviews: PendingReview[] = [
    {
      id: '1',
      userId: 'user1',
      userName: 'Sarah Chen',
      userEmail: 'sarah.chen@email.com',
      skillName: 'React Development',
      description: 'I can teach React fundamentals, hooks, and advanced patterns. 3+ years of experience.',
      submittedAt: '2024-01-15T10:30:00Z',
      status: 'pending'
    },
    {
      id: '2',
      userId: 'user2',
      userName: 'Alex Rodriguez',
      userEmail: 'alex.rodriguez@email.com',
      skillName: 'Java Programming',
      description: 'Expert in Java, Spring Boot, and enterprise development. Available for mentoring.',
      submittedAt: '2024-01-14T15:45:00Z',
      status: 'pending'
    },
    {
      id: '3',
      userId: 'user3',
      userName: 'Emily Johnson',
      userEmail: 'emily.johnson@email.com',
      skillName: 'UI/UX Design',
      description: 'Professional UI/UX designer with expertise in Figma, Adobe XD, and design systems.',
      submittedAt: '2024-01-13T09:20:00Z',
      status: 'pending'
    },
    {
      id: '4',
      userId: 'user4',
      userName: 'David Kim',
      userEmail: 'david.kim@email.com',
      skillName: 'Machine Learning',
      description: 'ML engineer specializing in Python, TensorFlow, and computer vision applications.',
      submittedAt: '2024-01-12T14:15:00Z',
      status: 'pending'
    },
    {
      id: '5',
      userId: 'user5',
      userName: 'Maria Garcia',
      userEmail: 'maria.garcia@email.com',
      skillName: 'DevOps & AWS',
      description: 'DevOps engineer with AWS, Docker, and CI/CD pipeline expertise.',
      submittedAt: '2024-01-11T11:00:00Z',
      status: 'pending'
    }
  ];

  // Mock data for users
  const mockUsers: User[] = [
    {
      id: 'user1',
      name: 'Sarah Chen',
      email: 'sarah.chen@email.com',
      status: 'active',
      lastActive: '2 hours ago',
      joinDate: '2023-12-01',
      totalSwaps: 15,
      avgRating: 4.8
    },
    {
      id: 'user2',
      name: 'Alex Rodriguez',
      email: 'alex.rodriguez@email.com',
      status: 'active',
      lastActive: '1 day ago',
      joinDate: '2023-11-15',
      totalSwaps: 8,
      avgRating: 4.5
    },
    {
      id: 'user3',
      name: 'Emily Johnson',
      email: 'emily.johnson@email.com',
      status: 'suspended',
      lastActive: '3 days ago',
      joinDate: '2023-10-20',
      totalSwaps: 12,
      avgRating: 4.2
    },
    {
      id: 'user4',
      name: 'David Kim',
      email: 'david.kim@email.com',
      status: 'active',
      lastActive: '5 hours ago',
      joinDate: '2023-12-10',
      totalSwaps: 6,
      avgRating: 4.7
    },
    {
      id: 'user5',
      name: 'Maria Garcia',
      email: 'maria.garcia@email.com',
      status: 'banned',
      lastActive: '1 week ago',
      joinDate: '2023-09-05',
      totalSwaps: 3,
      avgRating: 3.8
    },
    {
      id: 'user6',
      name: 'James Wilson',
      email: 'james.wilson@email.com',
      status: 'active',
      lastActive: '30 minutes ago',
      joinDate: '2024-01-01',
      totalSwaps: 2,
      avgRating: 4.9
    }
  ];

  useEffect(() => {
    setPendingReviews(mockPendingReviews);
    setUsers(mockUsers);
  }, []);

  const handleApproveReview = (reviewId: string) => {
    setPendingReviews(prev => 
      prev.map(review => 
        review.id === reviewId 
          ? { ...review, status: 'approved' as const }
          : review
      )
    );
    setMetrics(prev => ({ ...prev, pendingReviews: prev.pendingReviews - 1 }));
    alert('Skill review approved successfully!');
  };

  const handleRejectReview = (reviewId: string) => {
    setPendingReviews(prev => 
      prev.map(review => 
        review.id === reviewId 
          ? { ...review, status: 'rejected' as const }
          : review
      )
    );
    setMetrics(prev => ({ ...prev, pendingReviews: prev.pendingReviews - 1 }));
    alert('Skill review rejected.');
  };

  const handleUserAction = (userId: string, action: 'suspend' | 'ban' | 'activate') => {
    setUsers(prev => 
      prev.map(user => {
        if (user.id === userId) {
          let newStatus: 'active' | 'suspended' | 'banned';
          switch (action) {
            case 'suspend':
              newStatus = 'suspended';
              break;
            case 'ban':
              newStatus = 'banned';
              break;
            case 'activate':
              newStatus = 'active';
              break;
            default:
              newStatus = user.status;
          }
          return { ...user, status: newStatus };
        }
        return user;
      })
    );

    // Update metrics
    setMetrics(prev => {
      const updatedUser = users.find(u => u.id === userId);
      if (!updatedUser) return prev;

      let suspendedUsers = prev.suspendedUsers;
      if (action === 'suspend' && updatedUser.status !== 'suspended') {
        suspendedUsers += 1;
      } else if (action === 'activate' && updatedUser.status === 'suspended') {
        suspendedUsers -= 1;
      }

      return { ...prev, suspendedUsers };
    });

    alert(`User ${action === 'activate' ? 'activated' : action + 'ed'} successfully!`);
  };

  const handleSendNotification = () => {
    if (notificationMessage.trim()) {
      alert(`Notification sent to all users: "${notificationMessage}"`);
      setShowNotificationModal(false);
      setNotificationMessage('');
    } else {
      alert('Please enter a message before sending.');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-600 bg-green-100';
      case 'suspended': return 'text-yellow-600 bg-yellow-100';
      case 'banned': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <>
      <section className="mb-8">
        <div className="bg-white shadow sm:rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">Admin Dashboard</h3>
            
            {/* Tab Navigation */}
            <div className="border-b border-gray-200 mb-6">
              <nav className="-mb-px flex space-x-8">
                <button
                  onClick={() => setActiveTab('overview')}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'overview'
                      ? 'border-indigo-500 text-indigo-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  Overview
                </button>
                <button
                  onClick={() => setActiveTab('reviews')}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'reviews'
                      ? 'border-indigo-500 text-indigo-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  Pending Reviews ({pendingReviews.filter(r => r.status === 'pending').length})
                </button>
                <button
                  onClick={() => setActiveTab('users')}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'users'
                      ? 'border-indigo-500 text-indigo-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  User Management ({users.length})
                </button>
                <button
                  onClick={() => setActiveTab('notifications')}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'notifications'
                      ? 'border-indigo-500 text-indigo-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  Notifications
                </button>
              </nav>
            </div>

            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <div>
                <h4 className="text-md font-medium text-gray-900 mb-4">Platform Metrics</h4>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="text-sm text-blue-800">Total Users</p>
                    <p className="text-2xl font-bold text-blue-600">{metrics.totalUsers}</p>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <p className="text-sm text-green-800">Active Swaps</p>
                    <p className="text-2xl font-bold text-green-600">{metrics.activeSwaps}</p>
                  </div>
                  <div className="bg-yellow-50 p-4 rounded-lg">
                    <p className="text-sm text-yellow-800">Completed Swaps</p>
                    <p className="text-2xl font-bold text-yellow-600">{metrics.completedSwaps}</p>
                  </div>
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <p className="text-sm text-purple-800">Avg. Rating</p>
                    <p className="text-2xl font-bold text-purple-600">{metrics.avgRating}</p>
                  </div>
                  <div className="bg-orange-50 p-4 rounded-lg">
                    <p className="text-sm text-orange-800">Pending Reviews</p>
                    <p className="text-2xl font-bold text-orange-600">{metrics.pendingReviews}</p>
                  </div>
                  <div className="bg-red-50 p-4 rounded-lg">
                    <p className="text-sm text-red-800">Suspended Users</p>
                    <p className="text-2xl font-bold text-red-600">{metrics.suspendedUsers}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div>
                    <h5 className="text-sm font-medium text-gray-900 mb-3">Recent Activity</h5>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="space-y-2 text-sm">
                        <p>• 2 new skill reviews submitted</p>
                        <p>• 5 skill swaps completed</p>
                        <p>• 1 user suspended for policy violation</p>
                        <p>• 3 new user registrations</p>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h5 className="text-sm font-medium text-gray-900 mb-3">Quick Actions</h5>
                    <div className="space-y-2">
                      <button
                        onClick={() => setActiveTab('reviews')}
                        className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 text-sm"
                      >
                        Review Pending Skills
                      </button>
                      <button
                        onClick={() => setActiveTab('users')}
                        className="w-full bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 text-sm"
                      >
                        Manage Users
                      </button>
                      <button
                        onClick={() => setShowNotificationModal(true)}
                        className="w-full bg-purple-600 text-white px-4 py-2 rounded-md hover:bg-purple-700 text-sm"
                      >
                        Send Notification
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Pending Reviews Tab */}
            {activeTab === 'reviews' && (
              <div>
                <h4 className="text-md font-medium text-gray-900 mb-4">Pending Skill Reviews</h4>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Skill</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Submitted</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {pendingReviews.filter(review => review.status === 'pending').map((review) => (
                        <tr key={review.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div>
                              <div className="text-sm font-medium text-gray-900">{review.userName}</div>
                              <div className="text-sm text-gray-500">{review.userEmail}</div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {review.skillName}
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-500 max-w-xs">
                            {review.description}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {formatDate(review.submittedAt)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button 
                              onClick={() => handleApproveReview(review.id)}
                              className="text-green-600 hover:text-green-900 mr-3"
                            >
                              Approve
                            </button>
                            <button 
                              onClick={() => handleRejectReview(review.id)}
                              className="text-red-600 hover:text-red-900"
                            >
                              Reject
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {pendingReviews.filter(review => review.status === 'pending').length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No pending reviews at the moment.</p>
                  </div>
                )}
              </div>
            )}

            {/* User Management Tab */}
            {activeTab === 'users' && (
              <div>
                <h4 className="text-md font-medium text-gray-900 mb-4">User Management</h4>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Active</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Swaps</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rating</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {users.map((user) => (
                        <tr key={user.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div>
                              <div className="text-sm font-medium text-gray-900">{user.name}</div>
                              <div className="text-sm text-gray-500">{user.email}</div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(user.status)}`}>
                              {user.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {user.lastActive}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {user.totalSwaps}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            ⭐ {user.avgRating}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            {user.status === 'active' ? (
                              <>
                                <button 
                                  onClick={() => handleUserAction(user.id, 'suspend')}
                                  className="text-yellow-600 hover:text-yellow-900 mr-2"
                                >
                                  Suspend
                                </button>
                                <button 
                                  onClick={() => handleUserAction(user.id, 'ban')}
                                  className="text-red-600 hover:text-red-900"
                                >
                                  Ban
                                </button>
                              </>
                            ) : user.status === 'suspended' ? (
                              <>
                                <button 
                                  onClick={() => handleUserAction(user.id, 'activate')}
                                  className="text-green-600 hover:text-green-900 mr-2"
                                >
                                  Activate
                                </button>
                                <button 
                                  onClick={() => handleUserAction(user.id, 'ban')}
                                  className="text-red-600 hover:text-red-900"
                                >
                                  Ban
                                </button>
                              </>
                            ) : (
                              <button 
                                onClick={() => handleUserAction(user.id, 'activate')}
                                className="text-green-600 hover:text-green-900"
                              >
                                Activate
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Notifications Tab */}
            {activeTab === 'notifications' && (
              <div>
                <h4 className="text-md font-medium text-gray-900 mb-4">Platform Notifications</h4>
                <div className="bg-gray-50 p-6 rounded-lg">
                  <p className="text-sm text-gray-600 mb-4">
                    Send notifications to all users on the platform. Use this feature to announce updates, 
                    policy changes, or important information.
                  </p>
                  <button
                    onClick={() => setShowNotificationModal(true)}
                    className="bg-indigo-600 text-white px-6 py-3 rounded-md hover:bg-indigo-700 font-medium"
                  >
                    Send Platform Notification
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Notification Modal */}
      {showNotificationModal && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">​</span>
            <div className="inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full sm:p-6">
              <div>
                <div className="mt-3 text-center sm:mt-5">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">Send Platform Notification</h3>
                  <div className="mt-2">
                    <textarea
                      rows={4}
                      value={notificationMessage}
                      onChange={(e) => setNotificationMessage(e.target.value)}
                      className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border border-gray-300 rounded-md mt-4"
                      placeholder="Enter your message to all users..."
                    />
                  </div>
                </div>
              </div>
              <div className="mt-5 sm:mt-6 sm:grid sm:grid-cols-2 sm:gap-3 sm:grid-flow-row-dense">
                <button
                  type="button"
                  onClick={handleSendNotification}
                  className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-indigo-600 text-base font-medium text-white hover:bg-indigo-700 focus:outline-none sm:col-start-2 sm:text-sm"
                >
                  Send
                </button>
                <button
                  type="button"
                  onClick={() => setShowNotificationModal(false)}
                  className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none sm:mt-0 sm:col-start-1 sm:text-sm"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}; 