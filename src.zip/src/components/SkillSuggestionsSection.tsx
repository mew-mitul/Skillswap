import React from 'react';

interface SkillSuggestion {
  id: number;
  name: string;
  avatar: string;
  location: string;
  skills: string[];
  availability: string;
  matchScore: number;
}

interface SkillSuggestionsSectionProps {
  suggestions: SkillSuggestion[];
  onRequestSwap: (userName: string, skills: string[]) => void;
  title?: string;
}

export const SkillSuggestionsSection: React.FC<SkillSuggestionsSectionProps> = ({
  suggestions,
  onRequestSwap,
  title = "Suggested Alternatives"
}) => {
  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return 'bg-green-100 text-green-800';
    if (score >= 70) return 'bg-blue-100 text-blue-800';
    if (score >= 50) return 'bg-yellow-100 text-yellow-800';
    return 'bg-gray-100 text-gray-800';
  };

  if (suggestions.length === 0) {
    return null;
  }

  return (
    <section className="mb-8">
      <div className="bg-white shadow sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">{title}</h3>
          <p className="text-sm text-gray-600 mb-4">
            Here are some alternative skill exchanges you might be interested in:
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {suggestions.map((suggestion) => (
              <div key={suggestion.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <img 
                      src={suggestion.avatar} 
                      alt={suggestion.name} 
                      className="h-10 w-10 rounded-full"
                    />
                    <div>
                      <h4 className="font-medium text-gray-900 text-sm">{suggestion.name}</h4>
                      <p className="text-xs text-gray-500">{suggestion.location}</p>
                    </div>
                  </div>
                  <span className={`px-2 py-1 text-xs rounded-full ${getMatchScoreColor(suggestion.matchScore)}`}>
                    {suggestion.matchScore}% match
                  </span>
                </div>
                
                <div className="mb-3">
                  <div className="flex flex-wrap gap-1">
                    {suggestion.skills.map((skill, index) => (
                      <span
                        key={index}
                        className="px-2 py-0.5 text-xs rounded-full bg-indigo-100 text-indigo-800"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div className="text-xs text-gray-600 mb-3">
                  Available: {suggestion.availability}
                </div>
                
                <button
                  onClick={() => onRequestSwap(suggestion.name, suggestion.skills)}
                  className="w-full px-3 py-1 text-xs rounded bg-indigo-600 text-white hover:bg-indigo-700 transition-colors"
                >
                  Request Swap
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}; 