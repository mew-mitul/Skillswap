import React from 'react';

export const WelcomeSection: React.FC = () => {
  return (
    <section className="bg-white shadow rounded-lg mb-8">
      <div className="px-6 py-8 text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Welcome to SkillSwap!</h2>
        <p className="text-lg text-gray-600 mb-6">Connect with your community and exchange skills with others.</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <div className="text-center">
            <div className="bg-indigo-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-search text-indigo-600 text-xl"></i>
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Discover Skills</h3>
            <p className="text-gray-600">Browse through available skills in your community</p>
          </div>
          <div className="text-center">
            <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-handshake text-green-600 text-xl"></i>
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Make Connections</h3>
            <p className="text-gray-600">Connect with people who share your interests</p>
          </div>
          <div className="text-center">
            <div className="bg-purple-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-graduation-cap text-purple-600 text-xl"></i>
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Learn & Teach</h3>
            <p className="text-gray-600">Share your expertise and learn from others</p>
          </div>
        </div>
      </div>
    </section>
  );
}; 