import React, { useState, useRef } from 'react';

interface User {
  id?: string;
  name: string;
  email: string;
  password?: string;
  profilePhoto?: string;
  location?: string;
  availability?: string[];
  visibility?: string;
  offeredSkills?: string[];
  wantedSkills?: string[];
  isAdmin?: boolean;
}

interface ProfileSectionProps {
  user: User;
  onSave: (profileData: any) => void;
}

export const ProfileSection: React.FC<ProfileSectionProps> = ({ user, onSave }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [profilePhoto, setProfilePhoto] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [profileData, setProfileData] = useState({
    name: user.name,
    location: 'Mumbai, Maharashtra',
    availability: ['Weekends', 'Weekday evenings'],
    visibility: 'Public'
  });

  const handleSave = () => {
    onSave({ ...profileData, photo: profilePhoto });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setProfileData({
      name: user.name,
      location: 'Mumbai, Maharashtra',
      availability: ['Weekends', 'Weekday evenings'],
      visibility: 'Public'
    });
    setProfilePhoto(null);
    setIsEditing(false);
  };

  const handleFileSelect = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfilePhoto(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      alert('Please select a valid image file.');
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handlePhotoClick = () => {
    if (isEditing) {
      fileInputRef.current?.click();
    }
  };

  const removePhoto = () => {
    setProfilePhoto(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const defaultPhoto = "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/1adf85e4-fb22-4be7-ad13-ad95f12dad41.png";

  return (
    <>
      <section className="bg-white shadow rounded-lg mb-8">
        <div className="px-6 py-5 border-b border-gray-200 flex justify-between items-center">
          <h3 className="text-lg leading-6 font-medium text-gray-900">My Profile</h3>
          <button 
            className="text-indigo-600 hover:text-indigo-900" 
            onClick={() => setIsEditing(true)}
          >
            Edit
          </button>
        </div>
        <div className="px-6 py-4">
          <div className="flex flex-col sm:flex-row gap-6">
            <div className="flex-shrink-0">
              <img 
                src={profilePhoto || defaultPhoto} 
                alt="Profile" 
                className="w-24 h-24 rounded-full mx-auto sm:mx-0 object-cover border-2 border-gray-200"
              />
            </div>
            <div className="flex-grow">
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700">Name</label>
                <p className="mt-1 text-sm text-gray-900">{profileData.name}</p>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700">Location</label>
                <p className="mt-1 text-sm text-gray-900">{profileData.location}</p>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700">Availability</label>
                <ul className="mt-1 text-sm text-gray-900">
                  {profileData.availability.map((item, index) => (
                    <li key={index}>{item}</li>
                  ))}
                </ul>
              </div>
              <div className="flex items-center">
                <span className="text-sm font-medium text-gray-700 mr-2">Profile Visibility:</span>
                <span className="text-sm text-gray-900">{profileData.visibility}</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Edit Profile Modal */}
      {isEditing && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div className="inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full sm:p-6">
              <div>
                <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">Edit Profile</h3>
                
                {/* Photo Upload Section */}
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Profile Photo</label>
                  <div className="flex items-center space-x-4">
                    <div className="flex-shrink-0">
                      <img 
                        src={profilePhoto || defaultPhoto} 
                        alt="Profile Preview" 
                        className="w-20 h-20 rounded-full object-cover border-2 border-gray-200"
                      />
                    </div>
                    <div className="flex-grow">
                      <div
                        className={`border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors ${
                          isDragOver 
                            ? 'border-indigo-400 bg-indigo-50' 
                            : 'border-gray-300 hover:border-indigo-300'
                        }`}
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        onDrop={handleDrop}
                        onClick={handlePhotoClick}
                      >
                        <i className="fas fa-cloud-upload-alt text-2xl text-gray-400 mb-2"></i>
                        <p className="text-sm text-gray-600">
                          {isDragOver ? 'Drop your photo here' : 'Click to upload or drag and drop'}
                        </p>
                        <p className="text-xs text-gray-500 mt-1">PNG, JPG, GIF up to 5MB</p>
                      </div>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleFileInputChange}
                        className="hidden"
                      />
                      {profilePhoto && (
                        <button
                          type="button"
                          onClick={removePhoto}
                          className="mt-2 text-sm text-red-600 hover:text-red-800 flex items-center"
                        >
                          <i className="fas fa-trash mr-1"></i>
                          Remove photo
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                  <input
                    type="text"
                    value={profileData.name}
                    onChange={(e) => setProfileData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-3 py-2 border rounded-md"
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                  <input
                    type="text"
                    value={profileData.location}
                    onChange={(e) => setProfileData(prev => ({ ...prev, location: e.target.value }))}
                    className="w-full px-3 py-2 border rounded-md"
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Availability</label>
                  <textarea
                    value={profileData.availability.join('\n')}
                    onChange={(e) => setProfileData(prev => ({ 
                      ...prev, 
                      availability: e.target.value.split('\n').filter(item => item.trim()) 
                    }))}
                    className="w-full px-3 py-2 border rounded-md"
                    rows={4}
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Profile Visibility</label>
                  <select
                    value={profileData.visibility}
                    onChange={(e) => setProfileData(prev => ({ ...prev, visibility: e.target.value }))}
                    className="w-full px-3 py-2 border rounded-md"
                  >
                    <option value="Public">Public</option>
                    <option value="Private">Private</option>
                  </select>
                </div>
              </div>
              <div className="mt-5 sm:mt-6 sm:grid sm:grid-cols-2 sm:gap-3 sm:grid-flow-row-dense">
                <button
                  type="button"
                  onClick={handleSave}
                  className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-indigo-600 text-base font-medium text-white hover:bg-indigo-700 focus:outline-none sm:col-start-2 sm:text-sm"
                >
                  Save
                </button>
                <button
                  type="button"
                  onClick={handleCancel}
                  className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none sm:mt-0 sm:col-start-1 sm:text-sm"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}; 