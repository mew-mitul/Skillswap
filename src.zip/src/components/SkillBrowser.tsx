import React, { useState } from 'react';
import { Card, CardHeader, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Avatar } from './ui/avatar';

interface Skill {
  id: string;
  name: string;
  category: string;
  description: string;
  level: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  user: {
    id: string;
    name: string;
    avatar: string;
  };
}

interface SkillBrowserProps {
  skills?: Skill[];
  onRequestSwap?: (skillId: string) => void;
}

export const SkillBrowser: React.FC<SkillBrowserProps> = ({ 
  skills = [], 
  onRequestSwap 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = ['all', 'programming', 'design', 'marketing', 'writing', 'music', 'cooking'];

  const filteredSkills = skills.filter(skill => {
    const matchesSearch = skill.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         skill.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || skill.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'beginner': return 'success';
      case 'intermediate': return 'primary';
      case 'advanced': return 'warning';
      case 'expert': return 'error';
      default: return 'default';
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Browse Skills</h1>
        <p className="text-gray-600">Find people with skills you want to learn and offer to teach them something in return</p>
      </div>

      {/* Search and Filter */}
      <div className="mb-6 space-y-4">
        <Input
          placeholder="Search for skills..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-md"
        />
        
        <div className="flex flex-wrap gap-2">
          {categories.map(category => (
            <Button
              key={category}
              variant={selectedCategory === category ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category)}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </Button>
          ))}
        </div>
      </div>

      {/* Skills Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSkills.map(skill => (
          <Card key={skill.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  <Avatar src={skill.user.avatar} alt={skill.user.name} />
                  <div>
                    <h3 className="font-semibold text-gray-900">{skill.name}</h3>
                    <p className="text-sm text-gray-600">{skill.user.name}</p>
                  </div>
                </div>
                <Badge variant={getLevelColor(skill.level)} size="sm">
                  {skill.level}
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent>
              <p className="text-gray-700 mb-4">{skill.description}</p>
              <div className="flex items-center justify-between">
                <Badge variant="secondary" size="sm">
                  {skill.category}
                </Badge>
                <Button
                  size="sm"
                  onClick={() => onRequestSwap?.(skill.id)}
                >
                  Request Swap
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredSkills.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">No skills found matching your criteria</p>
          <p className="text-gray-400">Try adjusting your search or filters</p>
        </div>
      )}
    </div>
  );
}; 