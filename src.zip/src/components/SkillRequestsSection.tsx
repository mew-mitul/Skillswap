import React, { useState } from 'react';

interface SkillRequest {
  id: number;
  user: {
    name: string;
    avatar: string;
    location: string;
  };
  offeredSkill: string;
  wantedSkill: string;
  message: string;
  status: 'Pending' | 'Accepted' | 'Rejected';
  date: string;
  rating?: number;
}

interface SkillRequestsSectionProps {
  requests: SkillRequest[];
  onAccept: (requestId: number) => void;
  onReject: (requestId: number) => void;
  onRate: (requestId: number, rating: number) => void;
}

export const SkillRequestsSection: React.FC<SkillRequestsSectionProps> = ({
  requests,
  onAccept,
  onReject,
  onRate
}) => {
  const [activeTab, setActiveTab] = useState<'pending' | 'accepted' | 'rejected'>('pending');

  const filteredRequests = requests.filter(request => {
    if (activeTab === 'pending') return request.status === 'Pending';
    if (activeTab === 'accepted') return request.status === 'Accepted';
    if (activeTab === 'rejected') return request.status === 'Rejected';
    return false;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending': return 'bg-yellow-100 text-yellow-800';
      case 'Accepted': return 'bg-green-100 text-green-800';
      case 'Rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleAccept = (requestId: number) => {
    onAccept(requestId);
  };

  const handleReject = (requestId: number) => {
    if (window.confirm('Are you sure you want to reject this skill request?')) {
      onReject(requestId);
    }
  };

  const handleRate = (requestId: number, rating: number) => {
    onRate(requestId, rating);
  };

  return (
    <section className="mb-8">
      <div className="bg-white shadow sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">Skill Requests</h3>
          
          {/* Tab Navigation */}
          <div className="border-b border-gray-200 mb-6">
            <nav className="-mb-px flex space-x-8">
              <button
                onClick={() => setActiveTab('pending')}
                className={`py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'pending'
                    ? 'border-indigo-500 text-indigo-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Pending ({requests.filter(r => r.status === 'Pending').length})
              </button>
              <button
                onClick={() => setActiveTab('accepted')}
                className={`py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'accepted'
                    ? 'border-indigo-500 text-indigo-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Accepted ({requests.filter(r => r.status === 'Accepted').length})
              </button>
              <button
                onClick={() => setActiveTab('rejected')}
                className={`py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'rejected'
                    ? 'border-indigo-500 text-indigo-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Rejected ({requests.filter(r => r.status === 'Rejected').length})
              </button>
            </nav>
          </div>

          {/* Requests List */}
          <div className="space-y-4">
            {filteredRequests.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500">No {activeTab} requests found.</p>
              </div>
            ) : (
              filteredRequests.map((request) => (
                <div key={request.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <img 
                        src={request.user.avatar} 
                        alt={request.user.name} 
                        className="h-12 w-12 rounded-full"
                      />
                      <div>
                        <h4 className="font-medium text-gray-900">{request.user.name}</h4>
                        <p className="text-sm text-gray-500">{request.user.location}</p>
                        <p className="text-xs text-gray-400">{request.date}</p>
                      </div>
                    </div>
                    <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(request.status)}`}>
                      {request.status}
                    </span>
                  </div>
                  
                  <div className="mt-3">
                    <div className="flex items-center space-x-4 text-sm">
                      <div>
                        <span className="font-medium text-green-600">Offers:</span>
                        <span className="ml-1 text-gray-700">{request.offeredSkill}</span>
                      </div>
                      <div>
                        <span className="font-medium text-blue-600">Wants:</span>
                        <span className="ml-1 text-gray-700">{request.wantedSkill}</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mt-2">{request.message}</p>
                  </div>

                  {/* Action Buttons */}
                  {request.status === 'Pending' && (
                    <div className="mt-4 flex space-x-2">
                      <button
                        onClick={() => handleAccept(request.id)}
                        className="px-3 py-1 text-xs rounded bg-green-600 text-white hover:bg-green-700 transition-colors"
                      >
                        Accept
                      </button>
                      <button
                        onClick={() => handleReject(request.id)}
                        className="px-3 py-1 text-xs rounded bg-red-600 text-white hover:bg-red-700 transition-colors"
                      >
                        Reject
                      </button>
                    </div>
                  )}

                  {/* Rating for Accepted Requests */}
                  {request.status === 'Accepted' && !request.rating && (
                    <div className="mt-4">
                      <p className="text-sm text-gray-600 mb-2">Rate this skill exchange:</p>
                      <div className="flex space-x-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            onClick={() => handleRate(request.id, star)}
                            className="text-yellow-400 hover:text-yellow-500 text-lg"
                          >
                            ★
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Show Rating if Already Rated */}
                  {request.status === 'Accepted' && request.rating && (
                    <div className="mt-4">
                      <p className="text-sm text-gray-600">Your rating:</p>
                      <div className="flex space-x-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <span
                            key={star}
                            className={`text-lg ${star <= request.rating! ? 'text-yellow-400' : 'text-gray-300'}`}
                          >
                            ★
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </section>
  );
}; 