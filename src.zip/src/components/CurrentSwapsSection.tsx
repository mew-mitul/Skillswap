import React from 'react';

interface Swap {
  id: number;
  user: {
    name: string;
    avatar: string;
  };
  offers: string;
  wants: string;
  message: string;
  status: string;
  rating?: number;
}

interface CurrentSwapsSectionProps {
  swaps: Swap[];
  onAccept: (swapId: number) => void;
  onReject: (swapId: number) => void;
}

export const CurrentSwapsSection: React.FC<CurrentSwapsSectionProps> = ({
  swaps,
  onAccept,
  onReject
}) => {
  return (
    <section className="mb-8">
      <div className="bg-white shadow sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">Current Swaps</h3>
          <div className="mt-5">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3">
              {swaps.map((swap) => (
                <div key={swap.id} className="swap-card bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
                  <div className="p-4">
                    <div className="flex items-center">
                      <img src={swap.user.avatar} alt={`${swap.user.name}`} className="h-10 w-10 rounded-full" />
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-900">{swap.user.name}</p>
                        <p className="text-xs text-gray-500">Offers: {swap.offers}</p>
                        <p className="text-xs text-gray-500">Wants: {swap.wants}</p>
                      </div>
                    </div>
                    <div className="mt-3">
                      <p className="text-xs text-gray-600">"{swap.message}"</p>
                    </div>
                    <div className="mt-3 flex justify-between items-center">
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        swap.status === 'Pending' ? 'bg-blue-100 text-blue-800' :
                        swap.status === 'Active' ? 'bg-green-100 text-green-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {swap.status}
                      </span>
                      {swap.status === 'Pending' && (
                        <div className="flex space-x-2">
                          <button
                            onClick={() => onAccept(swap.id)}
                            className="px-2 py-1 text-xs rounded bg-green-100 text-green-800 hover:bg-green-200"
                          >
                            Accept
                          </button>
                          <button
                            onClick={() => onReject(swap.id)}
                            className="px-2 py-1 text-xs rounded bg-red-100 text-red-800 hover:bg-red-200"
                          >
                            Reject
                          </button>
                        </div>
                      )}
                    </div>
                    {swap.status === 'Completed' && swap.rating && (
                      <div className="mt-2 flex items-center">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <i
                              key={i}
                              className={`fas fa-star text-xs ${
                                i < swap.rating! ? 'text-yellow-400' : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                        <span className="ml-1 text-xs text-gray-500">"Excellent teacher!"</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}; 