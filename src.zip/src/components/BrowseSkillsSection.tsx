import React, { useState } from 'react';

interface BrowseUser {
  id: number;
  name: string;
  location: string;
  avatar: string;
  skills: string[];
  availability: string;
}

interface BrowseSkillsSectionProps {
  users: BrowseUser[];
  onRequestSwap: (userName: string, skills: string[]) => void;
}

export const BrowseSkillsSection: React.FC<BrowseSkillsSectionProps> = ({
  users,
  onRequestSwap
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredUsers = users.filter(user => {
    const skills = user.skills.map(skill => skill.toLowerCase());
    return skills.some(skill => skill.includes(searchTerm.toLowerCase()));
  });

  const handleRequestSwap = (user: BrowseUser) => {
    onRequestSwap(user.name, user.skills);
  };

  return (
    <section className="mb-8">
      <div className="bg-white shadow sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg leading-6 font-medium text-gray-900">Browse Skills</h3>
            <div className="relative">
              <input
                type="text"
                placeholder="Search skills..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 pr-4 py-2 border border-gray-300 rounded-md text-sm"
              />
              <i className="fas fa-search absolute left-3 top-3 text-gray-400"></i>
            </div>
          </div>
          
          <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filteredUsers.map((user) => (
              <div key={user.id} className="user-card bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
                <div className="p-4">
                  <div className="flex items-center">
                    <img src={user.avatar} alt={`${user.name}`} className="h-12 w-12 rounded-full" />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-900">{user.name}</p>
                      <p className="text-xs text-gray-500">{user.location}</p>
                      <div className="flex mt-1">
                        {user.skills.map((skill, index) => (
                          <span
                            key={index}
                            className="px-2 py-0.5 text-xs rounded-full bg-indigo-100 text-indigo-800"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="mt-3">
                    <p className="text-xs text-gray-600">Available: {user.availability}</p>
                  </div>
                  <button
                    onClick={() => handleRequestSwap(user)}
                    className="mt-4 w-full px-3 py-1 text-xs rounded bg-indigo-600 text-white hover:bg-indigo-700"
                  >
                    Request Swap
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}; 