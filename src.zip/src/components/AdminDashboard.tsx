import React, { useState } from 'react';
import { Card, CardHeader, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface AdminStats {
  totalUsers: number;
  totalSkills: number;
  pendingRequests: number;
  completedSwaps: number;
  activeUsers: number;
}

interface AdminDashboardProps {
  stats?: AdminStats;
  onRefresh?: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ 
  stats = {
    totalUsers: 0,
    totalSkills: 0,
    pendingRequests: 0,
    completedSwaps: 0,
    activeUsers: 0
  }, 
  onRefresh 
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'skills' | 'requests'>('overview');

  const statCards = [
    {
      title: 'Total Users',
      value: stats.totalUsers,
      change: '+12%',
      changeType: 'positive' as const,
      description: 'from last month'
    },
    {
      title: 'Total Skills',
      value: stats.totalSkills,
      change: '+8%',
      changeType: 'positive' as const,
      description: 'from last month'
    },
    {
      title: 'Pending Requests',
      value: stats.pendingRequests,
      change: '-5%',
      changeType: 'negative' as const,
      description: 'from last month'
    },
    {
      title: 'Completed Swaps',
      value: stats.completedSwaps,
      change: '+15%',
      changeType: 'positive' as const,
      description: 'from last month'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
            <p className="text-gray-600">Monitor and manage the skill swap platform</p>
          </div>
          <Button onClick={onRefresh} variant="outline">
            Refresh Data
          </Button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="mb-6">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            {[
              { id: 'overview', label: 'Overview' },
              { id: 'users', label: 'Users' },
              { id: 'skills', label: 'Skills' },
              { id: 'requests', label: 'Requests' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {statCards.map((stat, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                      <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                    </div>
                    <div className={`text-sm ${
                      stat.changeType === 'positive' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {stat.change}
                    </div>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">{stat.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Recent Activity */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <h3 className="text-lg font-semibold text-gray-900">Recent Users</h3>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[1, 2, 3, 4, 5].map(i => (
                    <div key={i} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gray-300 rounded-full"></div>
                        <div>
                          <p className="text-sm font-medium text-gray-900">User {i}</p>
                          <p className="text-xs text-gray-500">Joined 2 hours ago</p>
                        </div>
                      </div>
                      <Badge variant="success" size="sm">Active</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h3 className="text-lg font-semibold text-gray-900">Recent Swaps</h3>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[1, 2, 3, 4, 5].map(i => (
                    <div key={i} className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-900">Swap #{i}</p>
                        <p className="text-xs text-gray-500">Completed 1 hour ago</p>
                      </div>
                      <Badge variant="primary" size="sm">Completed</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Users Tab */}
      {activeTab === 'users' && (
        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold text-gray-900">User Management</h3>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600">User management interface will be implemented here.</p>
          </CardContent>
        </Card>
      )}

      {/* Skills Tab */}
      {activeTab === 'skills' && (
        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold text-gray-900">Skill Management</h3>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600">Skill management interface will be implemented here.</p>
          </CardContent>
        </Card>
      )}

      {/* Requests Tab */}
      {activeTab === 'requests' && (
        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold text-gray-900">Request Management</h3>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600">Request management interface will be implemented here.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}; 