import React, { useState } from 'react';

interface User {
  id?: string;
  name: string;
  email: string;
  password?: string;
  profilePhoto?: string;
  location?: string;
  availability?: string[];
  visibility?: string;
  offeredSkills?: string[];
  wantedSkills?: string[];
  isAdmin?: boolean;
}

type AppView = 'welcome' | 'profile' | 'browse' | 'swaps' | 'requests' | 'admin';

interface NavbarProps {
  currentView: AppView;
  onViewChange: (view: AppView) => void;
  currentUser: User | null;
  onLogout: () => void;
  onShowLogin: () => void;
  isAdmin: boolean;
  onToggleAdmin: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onViewChange,
  currentUser,
  onLogout,
  onShowLogin,
  isAdmin,
  onToggleAdmin
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const handleNavClick = (view: AppView) => {
    onViewChange(view);
    setMobileMenuOpen(false);
  };

  return (
    <nav className="bg-indigo-600 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <img 
                src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/0160be4a-950d-4026-a6a3-1f8d3581680d.png" 
                alt="SkillSwap logo" 
                className="h-8 w-8 rounded"
              />
              <span className="ml-2 text-xl font-bold">SkillSwap</span>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              <button
                onClick={() => handleNavClick('welcome')}
                className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  currentView === 'welcome'
                    ? 'border-indigo-300 text-white'
                    : 'border-transparent hover:border-gray-300 hover:text-gray-100'
                }`}
              >
                Home
              </button>
              <button
                onClick={() => handleNavClick('browse')}
                className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  currentView === 'browse'
                    ? 'border-indigo-300 text-white'
                    : 'border-transparent hover:border-gray-300 hover:text-gray-100'
                }`}
              >
                Browse Skills
              </button>
              <button
                onClick={() => handleNavClick('swaps')}
                className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  currentView === 'swaps'
                    ? 'border-indigo-300 text-white'
                    : 'border-transparent hover:border-gray-300 hover:text-gray-100'
                }`}
              >
                My Swaps
              </button>
              <button
                onClick={() => handleNavClick('requests')}
                className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  currentView === 'requests'
                    ? 'border-indigo-300 text-white'
                    : 'border-transparent hover:border-gray-300 hover:text-gray-100'
                }`}
              >
                Skill Requests
              </button>
              {isAdmin && (
                <button
                  onClick={() => handleNavClick('admin')}
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                    currentView === 'admin'
                      ? 'border-indigo-300 text-white'
                      : 'border-transparent hover:border-gray-300 hover:text-gray-100'
                  }`}
                >
                  Admin
                </button>
              )}
            </div>
          </div>
          <div className="hidden sm:ml-6 sm:flex sm:items-center">
            {currentUser ? (
              <>
                <button
                  onClick={() => handleNavClick('profile')}
                  className="bg-indigo-700 px-4 py-2 rounded-md text-sm font-medium hover:bg-indigo-800 transition-colors duration-200"
                >
                  Profile
                </button>
                <button
                  onClick={onLogout}
                  className="ml-4 bg-red-600 px-4 py-2 rounded-md text-sm font-medium hover:bg-red-700 transition-colors duration-200 flex items-center"
                >
                  <i className="fas fa-sign-out-alt mr-2"></i>
                  Logout
                </button>
              </>
            ) : (
              <button
                onClick={onShowLogin}
                className="bg-green-600 px-4 py-2 rounded-md text-sm font-medium hover:bg-green-700 transition-colors duration-200 flex items-center"
              >
                <i className="fas fa-sign-in-alt mr-2"></i>
                Login
              </button>
            )}
            {currentUser && currentUser.email === 'admin@123' && (
              <button
                onClick={onToggleAdmin}
                className="ml-4 text-sm text-gray-300 hover:text-white transition-colors duration-200"
              >
                {isAdmin ? 'Exit Admin' : 'Admin Mode'}
              </button>
            )}
          </div>
          <div className="-mr-2 flex items-center sm:hidden">
            <button
              type="button"
              onClick={toggleMobileMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-indigo-200 hover:text-white hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
            >
              <span className="sr-only">Open main menu</span>
              <i className="fas fa-bars"></i>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="sm:hidden">
          <div className="pt-2 pb-3 space-y-1">
            <button
              onClick={() => handleNavClick('welcome')}
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                currentView === 'welcome'
                  ? 'bg-indigo-700 border-indigo-300 text-white'
                  : 'border-transparent hover:bg-indigo-500 hover:border-gray-300 hover:text-white'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('browse')}
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                currentView === 'browse'
                  ? 'bg-indigo-700 border-indigo-300 text-white'
                  : 'border-transparent hover:bg-indigo-500 hover:border-gray-300 hover:text-white'
              }`}
            >
              Browse Skills
            </button>
            <button
              onClick={() => handleNavClick('swaps')}
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                currentView === 'swaps'
                  ? 'bg-indigo-700 border-indigo-300 text-white'
                  : 'border-transparent hover:bg-indigo-500 hover:border-gray-300 hover:text-white'
              }`}
            >
              My Swaps
            </button>
            <button
              onClick={() => handleNavClick('requests')}
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                currentView === 'requests'
                  ? 'bg-indigo-700 border-indigo-300 text-white'
                  : 'border-transparent hover:bg-indigo-500 hover:border-gray-300 hover:text-white'
              }`}
            >
              Skill Requests
            </button>
            {isAdmin && (
              <button
                onClick={() => handleNavClick('admin')}
                className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                  currentView === 'admin'
                    ? 'bg-indigo-700 border-indigo-300 text-white'
                    : 'border-transparent hover:bg-indigo-500 hover:border-gray-300 hover:text-white'
                }`}
              >
                Admin
              </button>
            )}
            {currentUser ? (
              <div className="mt-4 pt-4 border-t border-indigo-500">
                <button
                  onClick={() => handleNavClick('profile')}
                  className="bg-indigo-700 w-full text-left pl-3 pr-4 py-2 rounded text-base font-medium"
                >
                  Profile
                </button>
                <button
                  onClick={onLogout}
                  className="mt-2 bg-red-600 w-full text-left pl-3 pr-4 py-2 rounded text-base font-medium"
                >
                  Logout
                </button>
                {currentUser.email === 'admin@123' && (
                  <button
                    onClick={onToggleAdmin}
                    className="mt-2 text-gray-300 w-full text-left pl-3 pr-4 py-2 text-base font-medium"
                  >
                    {isAdmin ? 'Exit Admin' : 'Admin Mode'}
                  </button>
                )}
              </div>
            ) : (
              <div className="mt-4 pt-4 border-t border-indigo-500">
                <button
                  onClick={onShowLogin}
                  className="bg-green-600 w-full text-left pl-3 pr-4 py-2 rounded text-base font-medium"
                >
                  Login
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}; 