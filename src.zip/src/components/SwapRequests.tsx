import React, { useState } from 'react';
import { Card, CardHeader, CardContent, CardFooter } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar } from './ui/avatar';

interface SwapRequest {
  id: string;
  status: 'pending' | 'accepted' | 'rejected' | 'completed';
  requester: {
    id: string;
    name: string;
    avatar: string;
  };
  requestedSkill: {
    id: string;
    name: string;
    description: string;
  };
  offeredSkill: {
    id: string;
    name: string;
    description: string;
  };
  createdAt: string;
  message?: string;
}

interface SwapRequestsProps {
  requests?: SwapRequest[];
  onAccept?: (requestId: string) => void;
  onReject?: (requestId: string) => void;
  onComplete?: (requestId: string) => void;
}

export const SwapRequests: React.FC<SwapRequestsProps> = ({ 
  requests = [], 
  onAccept, 
  onReject, 
  onComplete 
}) => {
  const [activeTab, setActiveTab] = useState<'incoming' | 'outgoing'>('incoming');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'warning';
      case 'accepted': return 'success';
      case 'rejected': return 'error';
      case 'completed': return 'primary';
      default: return 'default';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Pending';
      case 'accepted': return 'Accepted';
      case 'rejected': return 'Rejected';
      case 'completed': return 'Completed';
      default: return status;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Swap Requests</h1>
        <p className="text-gray-600">Manage your skill swap requests and offers</p>
      </div>

      {/* Tabs */}
      <div className="mb-6">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('incoming')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'incoming'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Incoming Requests
            </button>
            <button
              onClick={() => setActiveTab('outgoing')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'outgoing'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Outgoing Requests
            </button>
          </nav>
        </div>
      </div>

      {/* Requests List */}
      <div className="space-y-4">
        {requests.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <p className="text-gray-500 text-lg">
                {activeTab === 'incoming' 
                  ? 'No incoming swap requests' 
                  : 'No outgoing swap requests'
                }
              </p>
              <p className="text-gray-400">
                {activeTab === 'incoming' 
                  ? 'When someone requests to swap skills with you, they\'ll appear here' 
                  : 'Your skill swap requests will appear here'
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          requests.map(request => (
            <Card key={request.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <Avatar src={request.requester.avatar} alt={request.requester.name} />
                    <div>
                      <h3 className="font-semibold text-gray-900">{request.requester.name}</h3>
                      <p className="text-sm text-gray-600">
                        Requested on {formatDate(request.createdAt)}
                      </p>
                    </div>
                  </div>
                  <Badge variant={getStatusColor(request.status)}>
                    {getStatusText(request.status)}
                  </Badge>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Wants to learn:</h4>
                    <div className="bg-blue-50 p-3 rounded-md">
                      <p className="font-medium text-blue-900">{request.requestedSkill.name}</p>
                      <p className="text-sm text-blue-700">{request.requestedSkill.description}</p>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Offers to teach:</h4>
                    <div className="bg-green-50 p-3 rounded-md">
                      <p className="font-medium text-green-900">{request.offeredSkill.name}</p>
                      <p className="text-sm text-green-700">{request.offeredSkill.description}</p>
                    </div>
                  </div>
                </div>

                {request.message && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Message:</h4>
                    <p className="text-gray-700 bg-gray-50 p-3 rounded-md">{request.message}</p>
                  </div>
                )}
              </CardContent>

              {request.status === 'pending' && activeTab === 'incoming' && (
                <CardFooter>
                  <div className="flex space-x-3 w-full">
                    <Button
                      variant="primary"
                      onClick={() => onAccept?.(request.id)}
                      className="flex-1"
                    >
                      Accept
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => onReject?.(request.id)}
                      className="flex-1"
                    >
                      Decline
                    </Button>
                  </div>
                </CardFooter>
              )}

              {request.status === 'accepted' && (
                <CardFooter>
                  <Button
                    variant="primary"
                    onClick={() => onComplete?.(request.id)}
                    className="w-full"
                  >
                    Mark as Completed
                  </Button>
                </CardFooter>
              )}
            </Card>
          ))
        )}
      </div>
    </div>
  );
}; 