import React, { useState } from 'react';

interface RequestedSkill {
  skill: string;
  from: string;
  status: 'Pending' | 'Accepted' | 'Rejected';
  date: string;
}

interface SkillsSectionProps {
  offeredSkills: string[];
  wantedSkills: string[];
  requestedSkills: RequestedSkill[];
  onAddSkill: (skill: string, type: 'offered' | 'wanted') => void;
  onRemoveSkill: (skill: string, type: 'offered' | 'wanted') => void;
}

export const SkillsSection: React.FC<SkillsSectionProps> = ({
  offeredSkills,
  wantedSkills,
  requestedSkills,
  onAddSkill,
  onRemoveSkill
}) => {
  const [activeTab, setActiveTab] = useState<'offered' | 'wanted' | 'requested'>('offered');

  const handleAddSkill = (type: 'offered' | 'wanted') => {
    const skill = prompt(`Enter a skill you want to ${type === 'offered' ? 'offer' : 'learn'}:`);
    if (skill) {
      onAddSkill(skill, type);
    }
  };

  const handleRemoveSkill = (skill: string, type: 'offered' | 'wanted') => {
    if (window.confirm(`Remove ${skill}?`)) {
      onRemoveSkill(skill, type);
    }
  };

  const getStatusClass = (status: string) => {
    switch(status) {
      case 'Pending': return 'bg-blue-100 text-blue-800';
      case 'Accepted': return 'bg-green-100 text-green-800';
      case 'Rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <section className="mb-8">
      <div className="bg-white shadow sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">My Skills</h3>
          <div className="mt-5 flex">
            <div className="flex-1">
              <button
                onClick={() => setActiveTab('offered')}
                className={`px-4 py-2 border-b-2 text-sm font-medium ${
                  activeTab === 'offered'
                    ? 'border-indigo-500 text-indigo-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Skills I Offer
              </button>
            </div>
            <div className="flex-1">
              <button
                onClick={() => setActiveTab('wanted')}
                className={`px-4 py-2 border-b-2 text-sm font-medium ${
                  activeTab === 'wanted'
                    ? 'border-indigo-500 text-indigo-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Skills I Need
              </button>
            </div>
            <div className="flex-1">
              <button
                onClick={() => setActiveTab('requested')}
                className={`px-4 py-2 border-b-2 text-sm font-medium ${
                  activeTab === 'requested'
                    ? 'border-indigo-500 text-indigo-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Requested Skills
              </button>
            </div>
          </div>
          
          <div className="mt-4">
            {activeTab === 'offered' && (
              <div>
                <div className="flex justify-between items-center mb-4">
                  <p className="text-sm text-gray-500">List skills you're willing to teach others</p>
                  <button
                    onClick={() => handleAddSkill('offered')}
                    className="text-indigo-600 hover:text-indigo-900 text-sm font-medium"
                  >
                    + Add Skill
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {offeredSkills.map((skill, index) => (
                    <span
                      key={index}
                      onClick={() => handleRemoveSkill(skill, 'offered')}
                      className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800 cursor-pointer hover:bg-indigo-200"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'wanted' && (
              <div>
                <div className="flex justify-between items-center mb-4">
                  <p className="text-sm text-gray-500">List skills you want to learn</p>
                  <button
                    onClick={() => handleAddSkill('wanted')}
                    className="text-indigo-600 hover:text-indigo-900 text-sm font-medium"
                  >
                    + Add Skill
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {wantedSkills.map((skill, index) => (
                    <span
                      key={index}
                      onClick={() => handleRemoveSkill(skill, 'wanted')}
                      className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 cursor-pointer hover:bg-green-200"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'requested' && (
              <div>
                <div className="flex justify-between items-center mb-4">
                  <p className="text-sm text-gray-500">Skills you've requested from others</p>
                </div>
                <div className="space-y-2">
                  {requestedSkills.length === 0 ? (
                    <p className="text-sm text-gray-500">No skills requested yet</p>
                  ) : (
                    requestedSkills.map((skill, index) => (
                      <div key={index} className="w-full bg-white p-3 rounded-lg border border-gray-200 flex justify-between items-center">
                        <div>
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                            {skill.skill}
                          </span>
                          <span className="text-xs text-gray-500 ml-2">Requested from: {skill.from}</span>
                        </div>
                        <div className="flex items-center">
                          <span className={`px-2 py-1 text-xs rounded-full ${getStatusClass(skill.status)}`}>
                            {skill.status}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}; 