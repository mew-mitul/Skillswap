import React, { useState, useEffect } from 'react';
import { AuthModal } from './components/AuthModal';
import { Navbar } from './components/Navbar';
import { WelcomeSection } from './components/WelcomeSection';
import { ProfileSection } from './components/ProfileSection';
import { SkillsSection } from './components/SkillsSection';
import { CurrentSwapsSection } from './components/CurrentSwapsSection';
import { BrowseSkillsSection } from './components/BrowseSkillsSection';
import { SkillRequestsSection } from './components/SkillRequestsSection';
import { SkillSuggestionsSection } from './components/SkillSuggestionsSection';
import { AdminSection } from './components/AdminSection';
import { authAPI, userAPI, swapsAPI } from './services/api';

interface User {
  id?: string;
  name: string;
  email: string;
  password?: string;
  profilePhoto?: string;
  location?: string;
  availability?: string[];
  visibility?: string;
  offeredSkills?: string[];
  wantedSkills?: string[];
  isAdmin?: boolean;
}

interface RequestedSkill {
  skill: string;
  from: string;
  status: 'Pending' | 'Accepted' | 'Rejected';
  date: string;
}

type AppView = 'welcome' | 'profile' | 'browse' | 'swaps' | 'requests' | 'admin';

function App() {
  const [currentView, setCurrentView] = useState<AppView>('welcome');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [swaps, setSwaps] = useState<any[]>([]);
  const [skillRequests, setSkillRequests] = useState<any[]>([]);
  const [skillSuggestions, setSkillSuggestions] = useState<any[]>([]);
  const [requestedSkills, setRequestedSkills] = useState<any[]>([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(false);

  // Mock data
  const mockSkills = [
    'JavaScript',
    'React',
    'Node.js',
    'Python'
  ];

  const mockWantedSkills = [
    'Java',
    'C++',
    'Machine Learning'
  ];

  const mockSwaps = [
    {
      id: 1,
      user: {
        name: 'Sarah Chen',
        avatar: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/f5d2a97d-cca4-40cd-a65f-bf43fc8eed87.png'
      },
      offers: 'React Development',
      wants: 'Java Programming',
      message: 'I can teach React development in exchange for Java programming lessons.',
      status: 'Pending'
    },
    {
      id: 2,
      user: {
        name: 'Alex Rodriguez',
        avatar: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/2a577516-57cb-403b-a68e-710e6809887b.png'
      },
      offers: 'Spring Boot',
      wants: 'Python',
      message: 'I can teach Spring Boot in exchange for Python programming lessons.',
      status: 'Active'
    },
    {
      id: 3,
      user: {
        name: 'Emily Johnson',
        avatar: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/b92497e6-549a-4823-85ab-69a2f5dc864c.png'
      },
      offers: 'UI/UX Design',
      wants: 'C++ Programming',
      message: 'Need help learning C++. Can offer UI/UX design skills in return.',
      status: 'Completed',
      rating: 4
    }
  ];

  const mockBrowseUsers = [
    {
      id: 1,
      name: 'Sarah Chen',
      location: 'San Francisco, CA',
      avatar: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/29b0e701-a958-48cd-bd47-41a37fd4decd.png',
      skills: ['JavaScript', 'React', 'Node.js'],
      availability: 'Weekends'
    },
    {
      id: 2,
      name: 'Alex Rodriguez',
      location: 'Austin, TX',
      avatar: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/809c8ccc-4851-4ee6-a125-0aff16642cdd.png',
      skills: ['Java', 'Spring Boot', 'MySQL'],
      availability: 'Weekday evenings'
    },
    {
      id: 3,
      name: 'Emily Johnson',
      location: 'Seattle, WA',
      avatar: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/c6481043-3c89-4eb9-a001-a7ff6d0738a3.png',
      skills: ['HTML', 'CSS', 'UI/UX Design'],
      availability: 'Tuesday, Thursday evenings'
    },
    {
      id: 4,
      name: 'David Kim',
      location: 'New York, NY',
      avatar: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/b92497e6-549a-4823-85ab-69a2f5dc864c.png',
      skills: ['C++', 'Python', 'Data Structures'],
      availability: 'Monday, Wednesday, Friday'
    },
    {
      id: 5,
      name: 'Maria Garcia',
      location: 'Miami, FL',
      avatar: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/f5d2a97d-cca4-40cd-a65f-bf43fc8eed87.png',
      skills: ['PHP', 'Laravel', 'WordPress'],
      availability: 'Weekday afternoons'
    },
    {
      id: 6,
      name: 'James Wilson',
      location: 'Chicago, IL',
      avatar: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/2a577516-57cb-403b-a68e-710e6809887b.png',
      skills: ['C#', '.NET', 'SQL Server'],
      availability: 'Weekends and evenings'
    }
  ];

  // Mock skill requests data
  const mockSkillRequests = [
    {
      id: 1,
      user: {
        name: 'Michael Brown',
        avatar: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/29b0e701-a958-48cd-bd47-41a37fd4decd.png',
        location: 'Boston, MA'
      },
      offeredSkill: 'TypeScript',
      wantedSkill: 'React',
      message: 'I can teach TypeScript in exchange for React development lessons.',
      status: 'Pending' as const,
      date: '2024-01-15'
    },
    {
      id: 2,
      user: {
        name: 'Lisa Wang',
        avatar: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/809c8ccc-4851-4ee6-a125-0aff16642cdd.png',
        location: 'Seattle, WA'
      },
      offeredSkill: 'AWS Cloud',
      wantedSkill: 'Docker',
      message: 'Looking to learn Docker. Can offer AWS cloud services knowledge.',
      status: 'Accepted' as const,
      date: '2024-01-10'
    },
    {
      id: 3,
      user: {
        name: 'Robert Taylor',
        avatar: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/c6481043-3c89-4eb9-a001-a7ff6d0738a3.png',
        location: 'Austin, TX'
      },
      offeredSkill: 'GraphQL',
      wantedSkill: 'MongoDB',
      message: 'Need MongoDB expertise. Can teach GraphQL in return.',
      status: 'Rejected' as const,
      date: '2024-01-08'
    }
  ];

  // Mock requested skills data
  const mockRequestedSkills = [
    {
      skill: 'Java Programming',
      from: 'Alex Rodriguez',
      status: 'Pending' as const,
      date: '2024-01-15'
    },
    {
      skill: 'UI/UX Design',
      from: 'Emily Johnson',
      status: 'Accepted' as const,
      date: '2024-01-14'
    },
    {
      skill: 'Machine Learning',
      from: 'David Kim',
      status: 'Rejected' as const,
      date: '2024-01-13'
    }
  ];

  // Mock skill suggestions data
  const mockSkillSuggestions = [
    {
      id: 1,
      name: 'Jennifer Lee',
      avatar: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/b92497e6-549a-4823-85ab-69a2f5dc864c.png',
      location: 'Denver, CO',
      skills: ['Vue.js', 'Firebase', 'Tailwind CSS'],
      availability: 'Weekends',
      matchScore: 95
    },
    {
      id: 2,
      name: 'Carlos Martinez',
      avatar: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/f5d2a97d-cca4-40cd-a65f-bf43fc8eed87.png',
      location: 'Phoenix, AZ',
      skills: ['Angular', 'RxJS', 'TypeScript'],
      availability: 'Weekday evenings',
      matchScore: 87
    },
    {
      id: 3,
      name: 'Amanda Foster',
      avatar: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/2a577516-57cb-403b-a68e-710e6809887b.png',
      location: 'Portland, OR',
      skills: ['Next.js', 'Prisma', 'PostgreSQL'],
      availability: 'Tuesday, Thursday',
      matchScore: 82
    }
  ];

  const handleLogin = async (email: string, password: string) => {
    try {
      setLoading(true);
      
      // Check for admin login first
      if (email === 'admin@123' && password === '0000') {
        const adminUser = {
          id: 'admin',
          name: 'Admin',
          email: 'admin@123',
          isAdmin: true
        };
        setCurrentUser(adminUser);
        setIsAdmin(true);
        setShowAuthModal(false);
        setCurrentView('welcome');
        alert('Welcome Admin! You have admin privileges.');
        return;
      }
      
      // Try backend login
      try {
        const response = await authAPI.login(email, password);
        setCurrentUser(response.user);
        setIsAdmin(response.user.isAdmin || false);
        setShowAuthModal(false);
        setCurrentView('welcome');
        alert(`Welcome back, ${response.user.name}!`);
      } catch (backendError: any) {
        // Fallback to mock login for demo
        const mockUser = {
          id: 'demo-user',
          name: email.split('@')[0],
          email: email,
          isAdmin: false
        };
        setCurrentUser(mockUser);
        setIsAdmin(false);
        setShowAuthModal(false);
        setCurrentView('welcome');
        alert(`Welcome back, ${mockUser.name}! (Demo mode)`);
      }
    } catch (error: any) {
      alert(error.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (name: string, email: string, password: string) => {
    try {
      setLoading(true);
      
      // Try backend registration
      try {
        await authAPI.register(name, email, password);
        alert('Registration successful! Please login with your credentials.');
      } catch (backendError: any) {
        // Fallback to mock registration for demo
        alert('Registration successful! (Demo mode) Please login with your credentials.');
      }
    } catch (error: any) {
      alert(error.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    authAPI.logout();
    setCurrentUser(null);
    setIsAdmin(false);
    setShowAuthModal(true);
    setCurrentView('welcome');
  };

  const handleShowLogin = () => {
    setShowAuthModal(true);
  };

  const handleRequestSwap = async (userName: string, skills: string[]) => {
    try {
      // Add to requested skills list
      const newRequest = {
        skill: skills.join(', '),
        from: userName,
        status: 'Pending' as const,
        date: new Date().toLocaleDateString()
      };
      
      setRequestedSkills(prev => [...prev, newRequest]);
      
      // This would need to be implemented with actual user IDs
      alert(`Swap request sent to ${userName} for ${skills.join(', ')}! They'll respond soon.`);
    } catch (error: any) {
      alert(error.message || 'Failed to send swap request');
    }
  };

  const handleAcceptSkillRequest = (requestId: number) => {
    setSkillRequests(prev => 
      prev.map(request => 
        request.id === requestId 
          ? { ...request, status: 'Accepted' as const }
          : request
      )
    );
    
    // Update requested skills status if it matches
    setRequestedSkills(prev => 
      prev.map(request => 
        request.from === skillRequests.find(r => r.id === requestId)?.user.name
          ? { ...request, status: 'Accepted' as const }
          : request
      )
    );
    
    // Show suggestions after accepting
    setSkillSuggestions(mockSkillSuggestions);
    alert('Skill request accepted! Check out some alternative suggestions below.');
  };

  const handleRejectSkillRequest = (requestId: number) => {
    setSkillRequests(prev => 
      prev.map(request => 
        request.id === requestId 
          ? { ...request, status: 'Rejected' as const }
          : request
      )
    );
    
    // Update requested skills status if it matches
    setRequestedSkills(prev => 
      prev.map(request => 
        request.from === skillRequests.find(r => r.id === requestId)?.user.name
          ? { ...request, status: 'Rejected' as const }
          : request
      )
    );
    
    // Show suggestions after rejecting
    setSkillSuggestions(mockSkillSuggestions);
    alert('Skill request rejected. Here are some alternative suggestions.');
  };

  const handleRateSkillRequest = (requestId: number, rating: number) => {
    setSkillRequests(prev => 
      prev.map(request => 
        request.id === requestId 
          ? { ...request, rating }
          : request
      )
    );
    alert(`Thank you for rating! You gave ${rating} stars.`);
  };

  const handleAcceptSwap = (swapId: number) => {
    // Update swap status logic here
    alert('Swap accepted!');
  };

  const handleRejectSwap = (swapId: number) => {
    if (window.confirm('Are you sure you want to reject this swap?')) {
      // Remove swap logic here
      alert('Swap rejected.');
    }
  };

  const handleAddSkill = (skill: string, type: 'offered' | 'wanted') => {
    if (type === 'offered') {
      // Add to offered skills logic
      alert(`Added ${skill} to your offered skills.`);
    } else {
      // Add to wanted skills logic
      alert(`Added ${skill} to your wanted skills.`);
    }
  };

  const handleRemoveSkill = (skill: string, type: 'offered' | 'wanted') => {
    if (window.confirm(`Remove ${skill}?`)) {
      // Remove skill logic here
      alert(`Removed ${skill}.`);
    }
  };

  const handleSaveProfile = (profileData: any) => {
    // Save profile logic here
    if (profileData.photo) {
      alert('Profile updated successfully! Photo has been saved.');
    } else {
      alert('Profile updated successfully!');
    }
  };

  const handleToggleAdmin = () => {
    // Only allow admin user to toggle admin mode
    if (currentUser && currentUser.email === 'admin@123') {
      setIsAdmin(!isAdmin);
    } else {
      alert('Only admin users can access admin mode.');
    }
  };

  // Load data from database when user is logged in
  useEffect(() => {
    const loadData = async () => {
      if (currentUser && authAPI.getToken()) {
        try {
          // Load users for browsing
          const usersData = await userAPI.getAllUsers();
          setUsers(usersData);
          
          // Load user's swaps
          const swapsData = await swapsAPI.getSwaps();
          setSwaps(swapsData);
          
          // Initialize skill requests with mock data
          setSkillRequests(mockSkillRequests);
          setRequestedSkills(mockRequestedSkills);
        } catch (error) {
          console.error('Error loading data:', error);
          // Use mock data if backend is not available
          setUsers([]);
          setSwaps([]);
          setSkillRequests(mockSkillRequests);
          setRequestedSkills(mockRequestedSkills);
        }
      } else {
        // Initialize with mock data for faster loading
        setSkillRequests(mockSkillRequests);
        setRequestedSkills(mockRequestedSkills);
      }
    };

    loadData();
  }, [currentUser]);

  return (
    <div className="min-h-screen">
      {/* Auth Modal */}
      {showAuthModal && (
        <AuthModal
          onLogin={handleLogin}
          onRegister={handleRegister}
          onClose={() => setShowAuthModal(false)}
        />
      )}

      {/* Navigation */}
      <Navbar
        currentView={currentView}
        onViewChange={setCurrentView}
        currentUser={currentUser}
        onLogout={handleLogout}
        onShowLogin={handleShowLogin}
        isAdmin={isAdmin}
        onToggleAdmin={handleToggleAdmin}
      />

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentView === 'welcome' && (
          <WelcomeSection />
        )}

        {currentView === 'profile' && currentUser && (
          <ProfileSection
            user={currentUser}
            onSave={handleSaveProfile}
          />
        )}

        {currentView === 'swaps' && (
          <>
            <SkillsSection
              offeredSkills={mockSkills}
              wantedSkills={mockWantedSkills}
              requestedSkills={requestedSkills}
              onAddSkill={handleAddSkill}
              onRemoveSkill={handleRemoveSkill}
            />
            <CurrentSwapsSection
              swaps={mockSwaps}
              onAccept={handleAcceptSwap}
              onReject={handleRejectSwap}
            />
          </>
        )}

        {currentView === 'browse' && (
          <BrowseSkillsSection
            users={users.length > 0 ? users.map(user => ({
              id: parseInt(user.id || '0'),
              name: user.name,
              location: user.location || 'Unknown',
              avatar: user.profilePhoto || 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/1adf85e4-fb22-4be7-ad13-ad95f12dad41.png',
              skills: user.offeredSkills || [],
              availability: user.availability?.join(', ') || 'Not specified'
            })) : mockBrowseUsers}
            onRequestSwap={handleRequestSwap}
          />
        )}

        {currentView === 'requests' && (
          <>
            <SkillRequestsSection
              requests={skillRequests}
              onAccept={handleAcceptSkillRequest}
              onReject={handleRejectSkillRequest}
              onRate={handleRateSkillRequest}
            />
            {skillSuggestions.length > 0 && (
              <SkillSuggestionsSection
                suggestions={skillSuggestions}
                onRequestSwap={handleRequestSwap}
                title="Alternative Skill Suggestions"
              />
            )}
          </>
        )}

        {currentView === 'admin' && isAdmin && (
          <AdminSection />
        )}
      </main>
    </div>
  );
}

export default App; 